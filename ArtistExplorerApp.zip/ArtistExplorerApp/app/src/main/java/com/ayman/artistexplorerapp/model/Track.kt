package com.ayman.artistexplorerapp.model

import com.google.gson.annotations.SerializedName

data class TrackResponse(
    @SerializedName("track") val tracks: List<Track>?
)

data class Track(
    @SerializedName("idTrack") val id: String?,
    @SerializedName("strTrack") val name: String?,
    @SerializedName("strDuration") val duration: String?,
    @SerializedName("intTrackNumber") val trackNumber: String?
)