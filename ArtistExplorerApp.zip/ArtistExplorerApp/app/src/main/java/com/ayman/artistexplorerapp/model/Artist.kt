package com.ayman.artistexplorerapp.model

import com.google.gson.annotations.SerializedName

data class ArtistResponse(
    @SerializedName("artists") val artists: List<Artist>?
)

data class Artist(
    @SerializedName("idArtist") val id: String?,
    @SerializedName("strArtist") val name: String?,
    @SerializedName("strGenre") val genre: String?,
    @SerializedName("strBiographyEN") val biography: String?,
    @SerializedName("strArtistThumb") val thumb: String?,
    @SerializedName("strArtistBanner") val banner: String?
)