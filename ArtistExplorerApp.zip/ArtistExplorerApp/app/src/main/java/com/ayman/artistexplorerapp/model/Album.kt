package com.ayman.artistexplorerapp.model

import com.google.gson.annotations.SerializedName

data class AlbumResponse(
    @SerializedName("album") val albums: List<Album>?
)

data class Album(
    @SerializedName("idAlbum") val id: String?,
    @SerializedName("strAlbum") val name: String?,
    @SerializedName("strArtist") val artist: String?,
    @SerializedName("intYearReleased") val year: String?,
    @SerializedName("strGenre") val genre: String?,
    @SerializedName("strAlbumThumb") val thumb: String?,
    @SerializedName("strDescriptionEN") val description: String?
)