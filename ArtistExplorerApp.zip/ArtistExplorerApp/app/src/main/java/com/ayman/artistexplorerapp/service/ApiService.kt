// ApiService.kt
package com.ayman.artistexplorerapp.service

import com.ayman.artistexplorerapp.model.AlbumResponse
import com.ayman.artistexplorerapp.model.ArtistResponse
import com.ayman.artistexplorerapp.model.TrackResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("search.php")
    suspend fun searchArtist(@Query("s") artistName: String): Response<ArtistResponse>

    @GET("searchalbum.php")
    suspend fun searchAlbums(@Query("s") artistName: String): Response<AlbumResponse>

    @GET("album.php")
    suspend fun getAlbumDetail(@Query("m") albumId: String): Response<AlbumResponse>

    @GET("track.php")
    suspend fun getAlbumTracks(@Query("m") albumId: String): Response<TrackResponse>
}