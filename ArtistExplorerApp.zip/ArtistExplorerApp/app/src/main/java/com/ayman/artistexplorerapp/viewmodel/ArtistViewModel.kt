package com.ayman.artistexplorerapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ayman.artistexplorerapp.model.Album
import com.ayman.artistexplorerapp.model.Artist
import com.ayman.artistexplorerapp.model.Track
import com.ayman.artistexplorerapp.repository.ArtistRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ArtistState {
    object Loading : ArtistState()
    data class Success(val artist: Artist?, val albums: List<Album>) : ArtistState()
    data class Error(val message: String) : ArtistState()
}

sealed class AlbumDetailState {
    object Loading : AlbumDetailState()
    data class Success(val album: Album?, val tracks: List<Track>) : AlbumDetailState()
    data class Error(val message: String) : AlbumDetailState()
}

class ArtistViewModel(private val repository: ArtistRepository = ArtistRepository()) : ViewModel() {

    private val _artistState = MutableStateFlow<ArtistState>(ArtistState.Loading)
    val artistState: StateFlow<ArtistState> = _artistState.asStateFlow()

    private val _albumDetailState = MutableStateFlow<AlbumDetailState>(AlbumDetailState.Loading)
    val albumDetailState: StateFlow<AlbumDetailState> = _albumDetailState.asStateFlow()

    private var currentArtistName = "John Mayer"

    init {
        loadArtistData()
    }

    fun loadArtistData(artistName: String = currentArtistName) {
        currentArtistName = artistName
        viewModelScope.launch {
            _artistState.value = ArtistState.Loading

            val artistResult = repository.getArtist(artistName)
            val albumsResult = repository.getAlbums(artistName)

            when {
                artistResult.isSuccess && albumsResult.isSuccess -> {
                    _artistState.value = ArtistState.Success(
                        artist = artistResult.getOrNull(),
                        albums = albumsResult.getOrNull() ?: emptyList()
                    )
                }
                artistResult.isFailure -> {
                    _artistState.value = ArtistState.Error(
                        artistResult.exceptionOrNull()?.message ?: "Error"
                    )
                }
                albumsResult.isFailure -> {
                    _artistState.value = ArtistState.Error(
                        albumsResult.exceptionOrNull()?.message ?: "Error"
                    )
                }
            }
        }
    }

    fun loadAlbumDetail(albumId: String) {
        viewModelScope.launch {
            _albumDetailState.value = AlbumDetailState.Loading

            val albumResult = repository.getAlbumDetail(albumId)
            val tracksResult = repository.getAlbumTracks(albumId)

            when {
                albumResult.isSuccess && tracksResult.isSuccess -> {
                    _albumDetailState.value = AlbumDetailState.Success(
                        album = albumResult.getOrNull(),
                        tracks = tracksResult.getOrNull() ?: emptyList()
                    )
                }
                albumResult.isFailure -> {
                    _albumDetailState.value = AlbumDetailState.Error(
                        albumResult.exceptionOrNull()?.message ?: "Error"
                    )
                }
                tracksResult.isFailure -> {
                    _albumDetailState.value = AlbumDetailState.Error(
                        tracksResult.exceptionOrNull()?.message ?: "Error"
                    )
                }
            }
        }
    }

    fun clearAlbumDetail() {
        _albumDetailState.value = AlbumDetailState.Loading
    }
}