package com.ayman.artistexplorerapp.repository

import com.ayman.artistexplorerapp.model.Album
import com.ayman.artistexplorerapp.model.Artist
import com.ayman.artistexplorerapp.model.Track
import com.ayman.artistexplorerapp.service.RetrofitInstance
import java.io.IOException

class ArtistRepository {
    suspend fun getArtist(artistName: String): Result<Artist?> {
        return try {
            val response = RetrofitInstance.api.searchArtist(artistName)
            if (response.isSuccessful) {
                val artists = response.body()?.artists
                Result.success(artists?.firstOrNull())
            } else {
                Result.failure(IOException("Failed to connect artist"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAlbums(artistName: String): Result<List<Album>> {
        return try {
            val response = RetrofitInstance.api.searchAlbums(artistName)
            if (response.isSuccessful) {
                val albums = response.body()?.albums ?: emptyList()
                Result.success(albums)
            } else {
                Result.failure(IOException("Failed to connect to albums"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAlbumDetail(albumId: String): Result<Album?> {
        return try {
            val response = RetrofitInstance.api.getAlbumDetail(albumId)
            if (response.isSuccessful) {
                val album = response.body()?.albums?.firstOrNull()
                Result.success(album)
            } else {
                Result.failure(IOException("Failed to connect to album details"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAlbumTracks(albumId: String): Result<List<Track>> {
        return try {
            val response = RetrofitInstance.api.getAlbumTracks(albumId)
            if (response.isSuccessful) {
                val tracks = response.body()?.tracks ?: emptyList()
                Result.success(tracks)
            } else {
                Result.failure(IOException("Failed to connect to tracks"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}