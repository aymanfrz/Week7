package com.ayman.artistexplorerapp.view

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun View(){

}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun Preview(){
    View()
}