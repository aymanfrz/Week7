package com.ayman.weatherapp.repository

import com.ayman.weatherapp.model.WeatherResponse
import com.ayman.weatherapp.service.RetrofitInstance

class WeatherRepository {
    private val apiKey = "83aa9c69ae77b8b3feb55e4932307f8d"

    suspend fun getWeatherData(city: String): Result<WeatherResponse> {
        return try {
            val response = RetrofitInstance.api.getCurrentWeather(city, apiKey)
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("HTTP ${response.code()}: ${response.message()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}