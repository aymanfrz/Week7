package com.ayman.weatherapp.model

// Hapus WeatherData yang tidak digunakan, kita hanya butuh WeatherResponse
data class WeatherResponse(
    val weather: List<Weather>,
    val main: Main,
    val name: String,
    val sys: Sys
)

data class Main(
    val temp: Double
)

data class Weather(
    val main: String,
    val description: String,
    val icon: String
)

data class Sys(
    val country: String
)