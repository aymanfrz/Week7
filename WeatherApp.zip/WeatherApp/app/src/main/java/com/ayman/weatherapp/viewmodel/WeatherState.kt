package com.ayman.weatherapp.viewmodel

import com.ayman.weatherapp.model.WeatherResponse

sealed class WeatherState {
    object Initial : WeatherState()
    object Loading : WeatherState()
    data class Success(val data: WeatherResponse) : WeatherState()
    data class Error(val message: String) : WeatherState()
}