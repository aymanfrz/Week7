package com.ayman.weatherapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ayman.weatherapp.repository.WeatherRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class WeatherViewModel : ViewModel() {
    private val repository = WeatherRepository()

    private val _weatherState = MutableStateFlow<WeatherState>(WeatherState.Initial)
    val weatherState: StateFlow<WeatherState> = _weatherState.asStateFlow()

    private val _searchText = MutableStateFlow("")
    val searchText: StateFlow<String> = _searchText.asStateFlow()

    fun updateSearchText(text: String) {
        _searchText.value = text
    }

    fun searchWeather() {
        val city = _searchText.value.trim()
        if (city.isNotEmpty()) {
            viewModelScope.launch {
                _weatherState.value = WeatherState.Loading
                val result = repository.getWeatherData(city)
                _weatherState.value = when {
                    result.isSuccess -> WeatherState.Success(result.getOrNull()!!)
                    else -> WeatherState.Error(result.exceptionOrNull()?.message ?: "Unknown error")
                }
            }
        }
    }
}